/**
 * @author johng
 * 
 * Holds the javascript logic that was originally in main.html
 * 
 */

var playermove;
var computermove;
var rps;
var start;
var end;
var position;
var playerCurLife;
var computerCurLife;

function init(){
	playermove = new Array();
	computermove = new Array();
	rps = ["rock", "paper", "scissors"];
	start = 40;
	end = 80;
	position = start;
	playerCurLife = 1;       
	computerCurLife = 1;     
	document.getElementById("player").src = "img/knight/brond/Ready.png";
	document.getElementById("computer").src = "img/knight/brond/Ready.png";
	
	document.addEventListener("deviceready", onDeviceReady, false);
	window.addEventListener('orientationchange', doOnOrientationChange);
	doOnOrientationChange();
	
	//init database
	initDB();
}


function onDeviceReady() {
	//device ready
}

/*
 * This  function is for orientation
 */
function doOnOrientationChange() {
	switch(window.orientation) {
		case -90:
		case 90:
			document.getElementById("life").style.top = "10px";
			document.getElementById("life").style.left = "120px";
			document.getElementById("rps").style.top = "30px";
			document.getElementById("rps").style.left = "-80px";
			document.getElementById("compare").style.top = "60px";
			document.getElementById("compare").style.left = "-80px";
			document.getElementById("motion").style.top = "100px";
			document.getElementById("motion").style.right = "-120px";
			break;
		default:
			document.getElementById("life").style.top = "auto";
			document.getElementById("life").style.left = "auto";
			document.getElementById("rps").style.top = "80px";
			document.getElementById("rps").style.left = "70px";
			document.getElementById("compare").style.top = "80px";
			document.getElementById("compare").style.left = "auto";
			document.getElementById("motion").style.top = "300px";
			document.getElementById("motion").style.right = "auto";
			break;
	}
}

/*
 * set up random array for computer
 * inital RPS js
 * intial Compare js
 * use fight() method display motion
 * reset arrays 
 */
function play() {
	for (var i = 0; i < 5; i++) {
		computermove.push(rps[Math.floor(Math.random() * 3)]);
	}
	initRPS(computermove, playermove);
	document.getElementById("compare").innerHTML = initCompare(computermove, playermove);
	fight(getComputer(), getPlayer());
	playermove = new Array();
	computermove = new Array();
}

/*
 * hide the rps triangle
 * display the compare
 * set up the time interval
 * when motion finish hide compare and display rps triangle
 */
function fight(computer, player) {
	var i = 0;
	var delay = 0;
	document.getElementById("rps").style.visibility = "hidden";
	document.getElementById("compare").style.visibility = "visible";
	var time = setInterval(function() {
		if (i < computer.length) {
			if (delay === 0) {
				document.getElementById("computer").src = "img/knight/brond/" + computer[i];
				document.getElementById("player").src = "img/knight/brond/" + player[i];
				if(player[i] === "Death1.png"){
					// player was hurt...
					someoneWasHurt("player");
				}
				if(computer[i] === "Death1.png"){
					// computer was hurt...
					someoneWasHurt("computer");
				}
			}
			delay++;
			getCompareNext();
			if (delay === 10) {
				delay = 0;
				switch(i%4) {
					case 0:
					case 2:
						move();
						break;
					case 1:
					//Add life change method;
						break;
					case 3:
					//Add method during charater in ready position
						break;
				}
				i++;
			}
		} else if (i < computer.length + 20) {
			getNext();
			i++;
		} else {
			clearInterval(time);
			document.getElementById("rps").style.visibility = "visible";
			document.getElementById("compare").style.visibility = "hidden";
		}

	}, 40);
}

//display how much player life left
function playerLife(i) {
	document.getElementById("pBlood").style.width = Math.floor(82 * i) + "px";
}

//display how much computer life left
function computerLife(i) {
	document.getElementById("eBlood").style.width = Math.floor(82 * i) + "px";
}

//switch poistion back and forward during two charater are fighting
function move() {
	if (position === start) {
		position = end;
	} else {
		position = start;
	}
	document.getElementById("player").style.left = position + "px";
	document.getElementById("computer").style.right = position + "px";
}

//Add rock, paper, or scissors into array
function add(id) {
	playermove.push(id);
}


function someoneWasHurt(type){
	if(type === "player"){
		//player was hurt
		playerCurLife = playerCurLife-.1;
		playerLife(playerCurLife); 
	}else{
		//computer was hurt
		computerCurLife = computerCurLife-.1;
		computerLife(computerCurLife);
	}
}